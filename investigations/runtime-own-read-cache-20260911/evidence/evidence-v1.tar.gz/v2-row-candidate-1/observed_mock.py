#!/usr/bin/env python3
"""Mock Anthropic /v1/messages that replays a scripted list of turns."""
import json, os, sys, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(sys.argv[1])
SCRIPT = json.load(open(sys.argv[2]))   # list of {"tool":..,"input":..} or {"text":..}
idx = {"i": 0}
lock = threading.Lock()

def sse(evt, obj):
    return ("event: %s\ndata: %s\n\n" % (evt, json.dumps(obj))).encode()

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def _read(self):
        n = int(self.headers.get("content-length") or 0)
        return self.rfile.read(n) if n else b""
    def do_GET(self):
        b=b'{}'; self.send_response(200)
        self.send_header("content-type","application/json"); self.send_header("content-length",str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_POST(self):
        raw = self._read()
        try: req = json.loads(raw or b"{}")
        except Exception: req = {}
        if not self.path.startswith("/v1/messages"):
            b=b'{}'; self.send_response(200)
            self.send_header("content-type","application/json"); self.send_header("content-length",str(len(b)))
            self.end_headers(); self.wfile.write(b); return
        txt = raw.decode("utf-8","replace")
        model = str(req.get("model",""))
        main = ('"name":"Write"' in txt or '"name": "Write"' in txt) and "haiku" not in model
        if main:
            blocks = [b for m in req.get('messages', []) if isinstance(m, dict) for b in (m.get('content') if isinstance(m.get('content'), list) else []) if isinstance(b, dict) and b.get('type') == 'tool_result']
            serialized = json.dumps(blocks)
            evidence = {'request_ordinal': idx['i'] + 1, 'tool_result_blocks': len(blocks), 'package_seen': 'GCLEAF_PACKAGE_0911' in serialized, 'source_seen': 'GCLEAF_SOURCE_0911' in serialized, 'any_tool_error': any(b.get('is_error', False) for b in blocks)}
            with open(os.environ['GCLEAF_MOCK_EVIDENCE'], 'a') as evidence_file:
                evidence_file.write(json.dumps(evidence) + '\n')
        turn = None
        with lock:
            if main and idx["i"] < len(SCRIPT):
                turn = SCRIPT[idx["i"]]; idx["i"] += 1
        sys.stderr.write("[mock] main=%s model=%s -> %s\n" % (main, model, json.dumps(turn) if turn else "text"))
        self.send_response(200)
        self.send_header("content-type","text/event-stream")
        self.send_header("cache-control","no-cache")
        self.send_header("transfer-encoding","chunked"); self.end_headers()
        def w(data):
            self.wfile.write(("%x\r\n" % len(data)).encode()+data+b"\r\n"); self.wfile.flush()
        msg = {"id":"msg_mock","type":"message","role":"assistant","model":model or "claude-sonnet-4-6",
               "content":[],"stop_reason":None,"stop_sequence":None,
               "usage":{"input_tokens":10,"output_tokens":1,"cache_creation_input_tokens":0,"cache_read_input_tokens":0}}
        w(sse("message_start", {"type":"message_start","message":msg}))
        text = (turn or {}).get("text", "Working." if turn else "OK.")
        w(sse("content_block_start", {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}))
        _st = int(os.environ.get("MOCK_CHUNK","0")) or len(text) or 1
        for k in range(0, len(text), _st):
            w(sse("content_block_delta", {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":text[k:k+_st]}}))
        w(sse("content_block_stop", {"type":"content_block_stop","index":0}))
        stop = "end_turn"
        if turn and turn.get("tool"):
            w(sse("content_block_start", {"type":"content_block_start","index":1,
                 "content_block":{"type":"tool_use","id":"toolu_mock%d" % idx["i"],"name":turn["tool"],"input":{}}}))
            payload = json.dumps(turn.get("input",{}))
            step = int(os.environ.get("MOCK_CHUNK", "0")) or len(payload)
            for k in range(0, len(payload), step):
                w(sse("content_block_delta", {"type":"content_block_delta","index":1,
                     "delta":{"type":"input_json_delta","partial_json":payload[k:k+step]}}))
            w(sse("content_block_stop", {"type":"content_block_stop","index":1}))
            stop = "tool_use"
        w(sse("message_delta", {"type":"message_delta","delta":{"stop_reason":stop,"stop_sequence":None},"usage":{"output_tokens":20}}))
        w(sse("message_stop", {"type":"message_stop"}))
        self.wfile.write(b"0\r\n\r\n"); self.wfile.flush()

ThreadingHTTPServer.allow_reuse_address = True
sys.stderr.write("[mock2] listening %d turns=%d\n" % (PORT, len(SCRIPT)))
ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
